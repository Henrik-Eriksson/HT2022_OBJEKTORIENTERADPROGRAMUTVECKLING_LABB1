﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Model;
using Calculator.View;
using Calculator.Controller;

namespace Calculator
{
    class Calculator
    {
        static void Main(string[] args)
        {
            CalculatorController controller = new CalculatorController();
            controller.Run();
        }
    }
}