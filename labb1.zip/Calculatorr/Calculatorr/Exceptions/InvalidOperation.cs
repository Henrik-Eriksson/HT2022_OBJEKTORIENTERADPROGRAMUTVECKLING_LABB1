﻿using Calculator.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Calculator.Exceptions
{
    internal class InvalidOperation : Exception
    {
        public InvalidOperation()
            : base("InvalidOperationException")
        {
        }
        public InvalidOperation(string message, Exception inner)
            : base(message, inner)
        {
        }

    }
}
