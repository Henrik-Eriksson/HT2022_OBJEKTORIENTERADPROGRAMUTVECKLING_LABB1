﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Model;
using Calculator.View;
using Calculator.Controller;
namespace Calculator.Exceptions
{
    class TokenException : Exception
    {

        public TokenException()
        {

        }

        public TokenException(string token)
            : base(String.Format("InvalidTokenException: {0}", token))
        {
        }
        public TokenException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}