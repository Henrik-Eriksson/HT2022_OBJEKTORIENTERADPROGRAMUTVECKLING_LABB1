﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Model;
using Calculator.View;
using Calculator.Controller;

namespace Calculator.Exceptions
{
    class ZeroException : Exception
    { 

        public ZeroException(double operand1, double operand2)
            : base(String.Format("DivideByZeroException: {0}/{1}", operand1, operand2))
        {
        }
        public ZeroException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}