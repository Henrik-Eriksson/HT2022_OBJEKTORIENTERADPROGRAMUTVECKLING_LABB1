﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Model;
using Calculator.View;
using Calculator.Controller;
namespace Calculator.Exceptions
{
    class InvalidTokenException : Exception
    {
        public InvalidTokenException()
        {
        }

        public InvalidTokenException(string message)
            : base(message)
        {
        }
        public InvalidTokenException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}