﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Model;
using Calculator.View;
using Calculator.Controller;
using Calculator.Model;
using System.IO;

namespace Calculator.Controller
{
    class CalculatorController
    {
        private ICalculatorView view;
        private ICalculatorModel model;

        public CalculatorController()
        {

            string[] args = Environment.GetCommandLineArgs();
            /* No command line args entered assumes input from user, Creates an instance of ConsoleCalculatorView */
            if (args.Length == 1)
            {
                view = new ConsoleCalculatorView();
            }
            /* If however command line args are entered validate input and create a instance of FileCalculatorView */
            else if (args.Length == 3)
            {
                if (args[1].EndsWith(".txt"))
                {
                    view = new FileCalculatorView(args[1], args[2]);
                }
                else
                {
                    Console.WriteLine("Felaktigt filnamn!");
                    return;
                }
            }
            else
            {
                Console.WriteLine("Felaktigt antal programväxlar!");
                return;
            }

            model = new CalculatorModel();
        }
        public void Run()
        {
            string rpnExpression = default;

            while (true)
            {
                /*Retrieves the expression from either File or Console input */
                rpnExpression = view.GetRpnExpression();

                if (rpnExpression == null || rpnExpression == "")
                {
                    view.PresentExitMessage();
                    break;
                }

                try
                {
                    double result = model.Calculate(rpnExpression);
                    view.PresentResult(result);
                }
                catch (Exception e)
                {
                    view.PresentErrorMessage(e.Message);
                }

            }
        }
    }
}