﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator.Model
{
    /* The RPNStack */
    internal class RPNStack : IRPNStack
    {
        private Stack<Token> stack;

        public RPNStack()
        {
            stack = new Stack<Token>();
        }

        public void Push(Token token)
        {
            stack.Push(token);
        }

        public void Clear()
        {
            stack.Clear();
        }

        public int Count()
        {
            return (stack.Count());
        }


        public Token Pop()
        {
            return stack.Pop();
        }
    }
}