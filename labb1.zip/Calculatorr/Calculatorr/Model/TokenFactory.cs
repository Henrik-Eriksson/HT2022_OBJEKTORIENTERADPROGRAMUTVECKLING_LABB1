﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Exceptions;

namespace Calculator.Model
{
    /* A factory for Tokens, Creates a Operator or Operand depending on the stringToken
 */
    internal class TokenFactory
    {
        public static Token CreateToken(string stringToken)
        {
            Token token = null;
            Console.WriteLine(stringToken);
            switch (stringToken)
            {
               
                case "+":
                    token = new SummationOperator();
                    break;
                case "-":
                    token = new DifferenceOperator();
                    break;
                case "*":
                    token = new ProductOperator();
                    break;
                case "/":
                    token = new QuotientOperator();
                    break;
                case "%":
                    token = new ModulusOperator();
                    break;
                default:
                    try 
                    { 
                        token = new Operand(double.Parse(stringToken));
                    }
                    catch (Exception)
                    {
                        throw new TokenException(stringToken);
                    }
                    break;
            }
            return token;
        }
    }
}