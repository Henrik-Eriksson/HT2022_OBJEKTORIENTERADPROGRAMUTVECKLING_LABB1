﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator.Model
{
    internal class Operand : Token
    {
        public double Value { get; set; }

        public Operand(double value)
        {
            Value = value;
        }

        public override double Process(IRPNStack stack)
        {
            return Value;
        }
    }
}