﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Model;
using Calculator.View;
using Calculator.Model;
using Calculator.Exceptions;

namespace Calculator.Model
{
    internal class CalculatorModel : ICalculatorModel
    {
        private RPNStack stack;

        public CalculatorModel()
        {
            stack = new RPNStack();
        }


        /* Input: Takes in a string and splits it up into tokens and pushes it into the stack
           Returns: The result from the RPN calculation
         */
        public double Calculate(string rpnExpression)
        {
            stack.Clear();
            string[] tokens = rpnExpression.Split(' ');
           
            foreach (string token in tokens)
            {
                stack.Push(TokenFactory.CreateToken(token));
            }

            double result = stack.Pop().Process(stack);
            if(stack.Count() != 0)
            {
                throw new InvalidOperation();
            }
            return result;

        }
    }
}