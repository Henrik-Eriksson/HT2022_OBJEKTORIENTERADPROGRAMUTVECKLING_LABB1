﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator.Model
{
    internal class SummationOperator : Operator
    {
        //overrides the abstract Process function so it fits the DifferenceOperator 
        public override double Process(IRPNStack stack)
        {
            double operand2 = stack.Pop().Process(stack);
            double operand1 = stack.Pop().Process(stack);
            double sum = operand1 + operand2;
            return sum;
        }
    }
}