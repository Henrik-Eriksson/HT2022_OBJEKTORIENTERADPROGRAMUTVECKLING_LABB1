﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Model;
using Calculator.View;
using Calculator.Controller;
using Calculator.Exceptions;


namespace Calculator.Model
{
    internal class ModulusOperator : Operator
    {
        //overrides the abstract Process function so it fits the ModulusOperator 
        public override double Process(IRPNStack stack)
        {
            double operand2 = stack.Pop().Process(stack);
            double operand1 = stack.Pop().Process(stack);

            if(operand2==0)
            {
                throw new ZeroException(operand1, operand2);
            }

            double sum = operand1 % operand2;
            return sum;
        }
    }
}
