﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Model;
using Calculator.View;
using Calculator.Controller;

namespace Calculator.View
{
    class ConsoleCalculatorView : ICalculatorView
    {
        public string GetRpnExpression()
        {
            Console.Write("Ange RPN uttryck <retur> (tom sträng = avsluta): ");
            return Console.ReadLine();
        }
        public void PresentResult(double result)
        {
            Console.WriteLine("Resultat: " + result);
        }
        public void PresentErrorMessage(string message)
        {
            Console.WriteLine("Felmeddelande: " + message);
        }
        public void PresentExitMessage()
        {
            Console.WriteLine("Användaren avslutade applikationen");
        }

    }
}