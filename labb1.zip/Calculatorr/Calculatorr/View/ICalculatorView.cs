﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Model;
using Calculator.View;
using Calculator.Controller;

namespace Calculator.View
{
    interface ICalculatorView
    {
        string GetRpnExpression();
        void PresentResult(double result);
        void PresentErrorMessage(string message);
        void PresentExitMessage();
    }
}