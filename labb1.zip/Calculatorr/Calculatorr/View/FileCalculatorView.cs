﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator.View
{
        class FileCalculatorView : ICalculatorView
        {
            private string filePath;
            private string fileResultPath;
            private int row;

            public FileCalculatorView(string fileName, string fileResultName)
            {
                this.filePath = $"{Environment.CurrentDirectory}\\{fileName}";
                this.fileResultPath = $"{Environment.CurrentDirectory}\\{fileResultName}";
                this.row = -1;
            }

            public string GetRpnExpression()
            {
                string[] lines = File.ReadAllLines(filePath);
                row += 1;

                if (row == lines.Length)
                {
                    return null;
                }

                return lines[row];
            }

            public void PresentResult(double result)
            {
                StreamWriter sw = File.AppendText(fileResultPath);
                Console.WriteLine(result);
                sw.WriteLine(result);
                sw.Close();
            }

            public void PresentErrorMessage(string errorMessage)
            {
                StreamWriter sw = File.AppendText(fileResultPath);
                sw.WriteLine(errorMessage);
                sw.Close();
            }

            public void PresentExitMessage()
            {
                StreamWriter sw = File.AppendText(fileResultPath);
                sw.WriteLine("Programmet avslutas");
                sw.Close();
            }
        }
}
